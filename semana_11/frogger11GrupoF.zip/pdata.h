#include "estruturas.h"

void salva_jogo(ESTADO estado);
int le_jogo_salvo(ESTADO *estado, char nome[]);
